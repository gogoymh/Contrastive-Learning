import torch
from torch.utils.data import DataLoader
from torchvision import transforms, datasets
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np

class sample_distribution:
    def __init__(self, x_centers=None, y_centers=None, var=0.1, plot=True):
        self.var = var
        
        if x_centers is  None:
            x_centers = [-4,-4,-4,-4,-4,
                         -2,-2,-2,-2,-2,
                         0,0,0,0,0,
                         2,2,2,2,2,
                         4,4,4,4,4]
        if y_centers is None:
            y_centers = [4,2,0,-2,-4,
                         4,2,0,-2,-4,
                         4,2,0,-2,-4,
                         4,2,0,-2,-4,
                         4,2,0,-2,-4]
        if plot:
            plt.scatter(x_centers, y_centers, s=100)
            plt.xlim(-5,5)
            plt.ylim(-5,5)
        
        self.length = len(x_centers)
        
        point = []
        for i in range(self.length):
            point.append([x_centers[i],y_centers[i]])
        self.point = np.array(point)
        #print(point)

    def sample(self, num, plot=False):
        minibatch = self.point[np.random.choice(self.length, num)]
        noise = np.random.normal(0,self.var,(num,2))
        
        dist = minibatch + noise
        
        if plot:
            plt.scatter(dist[:,0], dist[:,1], s=10)
            plt.xlim(-5,5)
            plt.ylim(-5,5)
        
        return dist

class rep1(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2,10)
        self.fc2 = nn.Linear(10,10)
        self.fc3 = nn.Linear(10,2)
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()
        
    def forward(self,x):
        out = self.relu(self.fc1(x))
        out = self.relu(self.fc2(out))
        out = self.tanh(self.fc3(out))
        return out

class rep2(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(100,50)
        self.fc2 = nn.Linear(50,10)
        self.fc3 = nn.Linear(10,2)
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()
        
    def forward(self,x):
        out = self.relu(self.fc1(x))
        out = self.relu(self.fc2(out))
        out = self.tanh(self.fc3(out))
        return out

class encoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2,16)
        self.fc2 = nn.Linear(16,32)
        self.relu = nn.ReLU()
        
    def forward(self,x):
        out = self.relu(self.fc1(x))
        out = self.fc2(out)
        return out

device = torch.device("cuda:0")
batch_size = 128
log_interval = 10

repnet1 = rep1().to(device)
repnet2 = rep2().to(device)
encode1 = encoder().to(device)
encode2 = encoder().to(device)

param1 = list(repnet1.parameters()) + list(encode1.parameters())
param2 = list(repnet2.parameters()) + list(encode2.parameters())

optim1 = optim.Adam(param1, lr=0.0001)
optim2 = optim.Adam(param2, lr=0.0001)

contrastive_loss = None

data = sample_distribution()

for iteration in range(10000):
    ## ---- real dist ---- ##
    optim1.zero_grad()
    
    x = data.sample(batch_size)
    x1 = x + np.random.normal(0,0.01,(batch_size,2))
    x2 = x + np.random.normal(0,0.01,(batch_size,2))
    
    x1 = torch.from_numpy(x1).float().to(device)
    x2 = torch.from_numpy(x2).float().to(device)

    out_real1 = encode1(repnet1(x1))
    out_real2 = encode1(repnet1(x2))

    real_loss = contrastive_loss(out_real1, out_real2)
    real_loss.backward()
    optim1.step()

    print("[Real contrastive loss:%f]" % real_loss.item())

    ## ---- latent dist ---- ##
    optim2.zero_grad()

    z = np.random.normal(0,1,(batch_size,100))
    z1 = z + np.random.normal(0,0.01,(batch_size,100))
    z2 = z + np.random.normal(0,0.01,(batch_size,100))

    z1 = torch.from_numpy(z1).float().to(device)
    z2 = torch.from_numpy(z2).float().to(device)

    out_latent1 = encode2(repnet2(z1))
    out_latent2 = encode2(repnet2(z2))

    latent_loss = contrastive_loss(out_latent1, out_latent2)
    latent_loss.backward()
    optim2.step()

    print("[Latent contrastive loss:%f]" % latent_loss.item())
    
    if (iteration+1) % log_interval == 0:
        torch.save("directory1.pth", repnet1.state_dict())
        torch.save("directory2.pth", repnet2.state_dict())

        x_sample = torch.from_numpy(data.sample(10000)).float().to(device)
        z_sample = torch.from_numpy(np.random.normal(0,1,(10000,100))).float().to(device)
        
        x_rep = repnet1(x_sample).detach().cpu().numpy()
        plt.scatter(x_rep[:,0], x_rep[:,1], s=10)
        plt.xlim(-5,5)
        plt.ylim(-5,5)
        plt.show()
        plt.close()
        
        z_rep = repnet2(z_sample).detach().cpu().numpy()
        plt.scatter(z_rep[:,0], z_rep[:,1], s=10)
        plt.xlim(-5,5)
        plt.ylim(-5,5)
        plt.show()
        plt.close()
        











